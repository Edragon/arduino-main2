/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var menudata={children:[
{text:"Main Page",url:"index.html"},
{text:"Topics",url:"topics.html"},
{text:"Namespaces",url:"namespaces.html",children:[
{text:"Namespace List",url:"namespaces.html"},
{text:"Namespace Members",url:"namespacemembers.html",children:[
{text:"All",url:"namespacemembers.html",children:[
{text:"a",url:"namespacemembers.html#index_a"},
{text:"e",url:"namespacemembers.html#index_e"},
{text:"g",url:"namespacemembers.html#index_g"},
{text:"k",url:"namespacemembers.html#index_k"},
{text:"l",url:"namespacemembers.html#index_l"},
{text:"n",url:"namespacemembers.html#index_n"},
{text:"p",url:"namespacemembers.html#index_p"},
{text:"r",url:"namespacemembers.html#index_r"},
{text:"s",url:"namespacemembers.html#index_s"}]},
{text:"Functions",url:"namespacemembers_func.html"},
{text:"Variables",url:"namespacemembers_vars.html",children:[
{text:"a",url:"namespacemembers_vars.html#index_a"},
{text:"e",url:"namespacemembers_vars.html#index_e"},
{text:"g",url:"namespacemembers_vars.html#index_g"},
{text:"l",url:"namespacemembers_vars.html#index_l"},
{text:"n",url:"namespacemembers_vars.html#index_n"},
{text:"p",url:"namespacemembers_vars.html#index_p"},
{text:"r",url:"namespacemembers_vars.html#index_r"},
{text:"s",url:"namespacemembers_vars.html#index_s"}]},
{text:"Enumerations",url:"namespacemembers_enum.html"},
{text:"Enumerator",url:"namespacemembers_eval.html"}]}]},
{text:"Classes",url:"annotated.html",children:[
{text:"Class List",url:"annotated.html"},
{text:"Class Index",url:"classes.html"},
{text:"Class Hierarchy",url:"hierarchy.html"},
{text:"Class Members",url:"functions.html",children:[
{text:"All",url:"functions.html",children:[
{text:"a",url:"functions.html#index_a"},
{text:"b",url:"functions_b.html#index_b"},
{text:"c",url:"functions_c.html#index_c"},
{text:"d",url:"functions_d.html#index_d"},
{text:"e",url:"functions_e.html#index_e"},
{text:"f",url:"functions_f.html#index_f"},
{text:"g",url:"functions_g.html#index_g"},
{text:"h",url:"functions_h.html#index_h"},
{text:"i",url:"functions_i.html#index_i"},
{text:"l",url:"functions_l.html#index_l"},
{text:"m",url:"functions_m.html#index_m"},
{text:"n",url:"functions_n.html#index_n"},
{text:"o",url:"functions_o.html#index_o"},
{text:"p",url:"functions_p.html#index_p"},
{text:"r",url:"functions_r.html#index_r"},
{text:"s",url:"functions_s.html#index_s"},
{text:"t",url:"functions_t.html#index_t"},
{text:"v",url:"functions_v.html#index_v"},
{text:"w",url:"functions_w.html#index_w"},
{text:"~",url:"functions_~.html#index__7E"}]},
{text:"Functions",url:"functions_func.html",children:[
{text:"a",url:"functions_func.html#index_a"},
{text:"b",url:"functions_func_b.html#index_b"},
{text:"c",url:"functions_func_c.html#index_c"},
{text:"d",url:"functions_func_d.html#index_d"},
{text:"e",url:"functions_func_e.html#index_e"},
{text:"g",url:"functions_func_g.html#index_g"},
{text:"h",url:"functions_func_h.html#index_h"},
{text:"i",url:"functions_func_i.html#index_i"},
{text:"l",url:"functions_func_l.html#index_l"},
{text:"m",url:"functions_func_m.html#index_m"},
{text:"o",url:"functions_func_o.html#index_o"},
{text:"p",url:"functions_func_p.html#index_p"},
{text:"r",url:"functions_func_r.html#index_r"},
{text:"s",url:"functions_func_s.html#index_s"},
{text:"t",url:"functions_func_t.html#index_t"},
{text:"v",url:"functions_func_v.html#index_v"},
{text:"w",url:"functions_func_w.html#index_w"},
{text:"~",url:"functions_func_~.html#index__7E"}]},
{text:"Variables",url:"functions_vars.html",children:[
{text:"a",url:"functions_vars.html#index_a"},
{text:"b",url:"functions_vars.html#index_b"},
{text:"c",url:"functions_vars.html#index_c"},
{text:"d",url:"functions_vars.html#index_d"},
{text:"f",url:"functions_vars.html#index_f"},
{text:"g",url:"functions_vars.html#index_g"},
{text:"i",url:"functions_vars.html#index_i"},
{text:"l",url:"functions_vars.html#index_l"},
{text:"m",url:"functions_vars.html#index_m"},
{text:"n",url:"functions_vars.html#index_n"},
{text:"o",url:"functions_vars.html#index_o"},
{text:"p",url:"functions_vars.html#index_p"},
{text:"r",url:"functions_vars.html#index_r"},
{text:"s",url:"functions_vars.html#index_s"},
{text:"t",url:"functions_vars.html#index_t"},
{text:"v",url:"functions_vars.html#index_v"},
{text:"w",url:"functions_vars.html#index_w"}]}]}]},
{text:"Files",url:"files.html",children:[
{text:"File List",url:"files.html"},
{text:"File Members",url:"globals.html",children:[
{text:"All",url:"globals.html",children:[
{text:"a",url:"globals.html#index_a"},
{text:"b",url:"globals.html#index_b"},
{text:"c",url:"globals.html#index_c"},
{text:"d",url:"globals.html#index_d"},
{text:"e",url:"globals.html#index_e"},
{text:"f",url:"globals.html#index_f"},
{text:"g",url:"globals.html#index_g"},
{text:"h",url:"globals.html#index_h"},
{text:"i",url:"globals.html#index_i"},
{text:"l",url:"globals.html#index_l"},
{text:"m",url:"globals.html#index_m"},
{text:"o",url:"globals.html#index_o"},
{text:"p",url:"globals.html#index_p"},
{text:"r",url:"globals.html#index_r"},
{text:"s",url:"globals.html#index_s"},
{text:"t",url:"globals.html#index_t"}]},
{text:"Functions",url:"globals_func.html"},
{text:"Variables",url:"globals_vars.html"},
{text:"Typedefs",url:"globals_type.html"},
{text:"Enumerations",url:"globals_enum.html"},
{text:"Enumerator",url:"globals_eval.html",children:[
{text:"a",url:"globals_eval.html#index_a"},
{text:"b",url:"globals_eval.html#index_b"},
{text:"c",url:"globals_eval.html#index_c"},
{text:"d",url:"globals_eval.html#index_d"},
{text:"i",url:"globals_eval.html#index_i"},
{text:"m",url:"globals_eval.html#index_m"},
{text:"r",url:"globals_eval.html#index_r"},
{text:"s",url:"globals_eval.html#index_s"}]},
{text:"Macros",url:"globals_defs.html",children:[
{text:"a",url:"globals_defs.html#index_a"},
{text:"d",url:"globals_defs.html#index_d"},
{text:"e",url:"globals_defs.html#index_e"},
{text:"f",url:"globals_defs.html#index_f"},
{text:"h",url:"globals_defs.html#index_h"},
{text:"i",url:"globals_defs.html#index_i"},
{text:"l",url:"globals_defs.html#index_l"},
{text:"o",url:"globals_defs.html#index_o"},
{text:"r",url:"globals_defs.html#index_r"},
{text:"t",url:"globals_defs.html#index_t"}]}]}]}]}
